package com.rrobotics.connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
