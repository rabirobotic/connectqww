import 'package:flutter/material.dart';

const indigo = Colors.indigo;
const white = Colors.white;
const black = Colors.black;
const amber = Colors.amber;
